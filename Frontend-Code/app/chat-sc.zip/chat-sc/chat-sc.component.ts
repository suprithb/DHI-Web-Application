import { Component, OnInit, AfterViewChecked, ElementRef, ViewChild } from '@angular/core';
import { formatDate } from '@angular/common';
import * as moment from 'moment';
import { WebsocketService } from "../websocket.service";
import { ChatService } from "../chat.service";
import { SpeechRecognitionService } from "../../services/speech-recognition.service";

@Component({
  selector: 'app-chat-sc',
  templateUrl: './chat-sc.component.html',
  styleUrls: ['./chat-sc.component.css'],
  providers: [WebsocketService, ChatService]
})
export class ChatScComponent implements OnInit, AfterViewChecked {
  @ViewChild('scrollMe') private myScrollContainer: ElementRef;
  @ViewChild('textarea') textarea: any;
  count: number = 0;
  text: string = "";
  src: string = "";
  response_count: number = 0;
  recording: Boolean;
  selected:string="tab_b";
  showSearchButton: boolean;
  speechData: string;

  constructor(private chatService: ChatService, private speechRecognitionService: SpeechRecognitionService) {
    chatService.messages.subscribe(msg => {
      console.log("Response from websocket: " + JSON.stringify(msg.message[0]));
      if (msg.message[0] == undefined)
        this.message.message = JSON.stringify(msg.message[1]);
      else
        this.message.message = JSON.stringify(msg.message[0]);

      if (msg.message[1] != "")
        this.src = msg.message[1];
      this.Bot_to_user();
    });

    this.showSearchButton = true;
    this.speechData = "";
  }
  private message = {
    message: this.text,
    handle: ""
  };
  getDatetime() {

    let span_date = document.createElement('span');
    let month = formatDate(new Date(), 'MM', 'en');
    span_date.innerHTML = moment(month, 'MM').format('MMMM') + " " + formatDate(new Date(), 'dd yyyy', 'en');;
    span_date.style.cssText = 'font-size:9px';


    let span_time = document.createElement('span');
    span_time.innerHTML = moment().format('hh:mm A');
    span_time.style.cssText = 'font-size:9px;padding-left:10px;'

    let sub_div = document.createElement('div');
    sub_div.appendChild(span_date);
    sub_div.appendChild(span_time);
    return sub_div
  }
  addimage(){
    document.getElementsByClassName('user-chat')[0].className+=" addimage"
  }
  Bot_to_user() {
    let newdiv = document.createElement('p');
    newdiv.onmouseover = this.addimage;
    let maindiv = document.createElement('div');
    var textnode;

    maindiv.style.cssText = 'display:table;position:relative;color:#646464;min-width:160px;'
    newdiv.style.cssText = 'margin-bottom: 3px;padding: 4px 20px;min-width:160px;border-radius: 4px;border-top-left-radius:0;color: #696969;background: #eeeeee;margin-left:111px;display:table;'

    textnode = this.message.message;
    newdiv.innerHTML = textnode;

    let sub_div = this.getDatetime();

    if (this.src != "null") {
      var img = new Image();
      img.src = this.src;
      sub_div.style.cssText = 'margin-left:25px;color: #cecbcb;margin-bottom:5px;';
      maindiv.appendChild(newdiv);
      maindiv.appendChild(img);
    }
    else {
      sub_div.style.cssText = 'margin-left:111px;color: #cecbcb;margin-bottom:5px;'
      maindiv.appendChild(newdiv);
    }
    maindiv.appendChild(sub_div);
    let pnum = document.getElementsByClassName('user-chat').length - 1
    let chat = document.getElementsByClassName('user-chat')[pnum].parentNode;
    chat.appendChild(maindiv);
  }
  onChange(){
    var active=document.querySelector('.tab-pane.active').classList.remove('active');
    var addactive=document.getElementById(this.selected).className+=" active";
  }
  ngOnInit() {
    this.scrollToBottom();
  }

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  scrollToBottom(): void {
    try {
      this.myScrollContainer.nativeElement.scrollTop = this.myScrollContainer.nativeElement.scrollHeight;
    } catch (err) {
      console.log(err);
    }
  }
  User_to_bot(e) {
    if (this.text != "") {
      let newdiv = document.createElement('p');
      newdiv.className += 'user-chat';
      let maindiv = document.createElement('div');
      var textnode;

      maindiv.style.cssText = 'display:table;position:relative;color:#646464;min-width:160px;'
      newdiv.style.cssText = 'margin-bottom: 3px;padding: 4px 20px;max-width: 250px;min-width:160px;border-radius: 4px;border-top-left-radius:0;color: #696969;background: #eeeeee;display:table;'

      textnode = document.createTextNode(this.text);
      newdiv.appendChild(textnode);

      let sub_div = this.getDatetime();
      sub_div.style.cssText = 'color: #cecbcb;margin-bottom:5px;'

      maindiv.appendChild(newdiv);
      maindiv.appendChild(sub_div);
      let chat = document.getElementsByClassName('chat-div')[0];
      chat.appendChild(maindiv);

      this.message.message = this.text;
      this.chatService.messages.next(this.message);
      this.text = "";
      this.recording = false;
    }
    else {
      this.recording = true;
      this.activateRecording();
    }
  }
  activateRecording(): void {
    this.showSearchButton = false;

    this.speechRecognitionService.record()
      .subscribe(
        //listener
        (value) => {
          this.speechData = value;
          console.log(value);
          this.recording = false;
          this.text = value;
          this.textarea.nativeElement.focus();
          this.speechRecognitionService.DestroySpeechObject();
        },
        //errror
        (err) => {
          console.log(err);
          if (err.error == "no-speech") {
            console.log("--restatring service--");
            this.activateRecording();
          }
        },
        //completion
        () => {
          this.showSearchButton = true;
          console.log("--complete--");
          // this.activateRecording();
        });
  }

}
