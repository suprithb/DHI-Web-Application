import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatScComponent } from './chat-sc.component';

describe('ChatScComponent', () => {
  let component: ChatScComponent;
  let fixture: ComponentFixture<ChatScComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChatScComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatScComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
